
const DBus = imports.dbus;
const Lang = imports.lang;
const St = imports.gi.St;
const Shell = imports.gi.Shell;
const Gio = imports.gi.Gio;
const Main = imports.ui.main;
const PopupMenu = imports.ui.popupMenu;
const Util = imports.misc.util;
const GLib = imports.gi.GLib;
const GnomeSession = imports.misc.gnomeSession;
const VolumeMenu = imports.ui.status.volume;
// CHANGE THE LINES 'const SEPERATOR, const VOLUME...' etc ONLY, to true or false!!!
//options are true to show and false to not show, you must already have installed the programs for this to run them
//try: sudo apt install pavucontrol paprefs pavumeter pulseaudio-equalizer paman
const POPUP_MENU = true; //adds shortcuts to popup menu on volume/sound menu
const POPUP_MENU_TEXT = "PulseAudio Settings"; //changes the text for the pop-up menu, default is PulseAudio Settings
const SEPERATOR = true;   //Shows a shiny seperator before the shortcuts, doesnt work with popup menu
const CUSTOM = true;   //Shows or hides the custom shortcut below(custom_command). The text shown can be modified below at 'CUSTOM_TEXT'.
const CUSTOM_TEXT = "Q Equalizer"; //the custom text for the custom_command below, this is just to change the text of the launcher
const CUSTOM_COMMAND = "qpaeq";   //Runs specified command, i.e by default it runs qpaeq which is a front-end for the newer module-equalizer-sink
const VOLUME = true;   //Runs PA Volume Control PA=Pulse Audio
const PREFS = true;   //Runs PA Preferences
const VUMETER = true;   //Runs PA VU Meter
const EQUALIZER = true;   //Runs the PA 'System-Wide' Equalizer.
const MANAGER = true;   //Starts the PA Manager, which can be used to restart pulse audio.
const PULSEAUDIO_TEXT = "PulseAudio "; //Optionally hide/change/remove the PulseAudio text, hint:add space at end if using text and must be "quoted" always!.
//DONT DO NOT touch anything below this line

let itemSeperator, paCustom, paVolume, paPrefs, paVumeter, paEqualizer, paManager, pulseMenu2, pulseMenu, nItems;

function _onCustomApp() {
    let app = Util.spawn([CUSTOM_COMMAND]);
    app.activate();
}

function init() {
}

function enable() {
    if (POPUP_MENU) {
        pulseMenu2 = Main.panel._statusArea.volume;
        pulseMenu = new PopupMenu.PopupSubMenuMenuItem(_(POPUP_MENU_TEXT));
        pulseMenu2.menu.addMenuItem(pulseMenu, pulseMenu2.menu.numMenuItems - 1);
        nItems = pulseMenu2.menu.numMenuItems;
    } else {
        pulseMenu = Main.panel._statusArea.volume;
        nItems = pulseMenu.menu.numMenuItems;
    if (SEPERATOR) {
        itemSeparator = new PopupMenu.PopupSeparatorMenuItem();
        pulseMenu.menu.addMenuItem(itemSeparator, nItems - 3);
    }
    }
    if (CUSTOM) {
        paCustom = new PopupMenu.PopupMenuItem(_(CUSTOM_TEXT), 0);
        paCustom.connect('activate', Lang.bind(paCustom, _onCustomApp));
        pulseMenu.menu.addMenuItem(paCustom, nItems - 2);
    }
    if (VOLUME) {
        paVolume = pulseMenu.menu.addSettingsAction(_(PULSEAUDIO_TEXT + "Volume Control"), 'pavucontrol.desktop', 0);
        pulseMenu.menu.addMenuItem(paVolume, nItems - 2);
    }
    if (PREFS) {
        paPrefs = pulseMenu.menu.addSettingsAction(_(PULSEAUDIO_TEXT + "Preferences"), 'paprefs.desktop', 0);
        pulseMenu.menu.addMenuItem(paPrefs, nItems - 2);
    }
    if (VUMETER) {
        paVumeter = pulseMenu.menu.addSettingsAction(_(PULSEAUDIO_TEXT + "Volume Meter"), 'pavumeter.desktop', 0);
        pulseMenu.menu.addMenuItem(paVumeter, nItems - 2);
    }
    if (EQUALIZER) {
        paEqualizer = pulseMenu.menu.addSettingsAction(_(PULSEAUDIO_TEXT + "Equalizer"), 'pulseaudio-equalizer.desktop', 0);
        pulseMenu.menu.addMenuItem(paEqualizer, nItems - 2);
    }
    if (MANAGER) {
        paManager = pulseMenu.menu.addSettingsAction(_(PULSEAUDIO_TEXT + "Manager"), 'paman.desktop', 0);
        pulseMenu.menu.addMenuItem(paManager, nItems - 2);
    }
}

function disable() {
    if (POPUP_MENU) {
        pulseMenu.destroy();
    } else {
    if (SEPERATOR)
        itemSeparator.destroy();

    if (paCustom)
        paCustom.destroy();

    if (paVolume)
        paVolume.destroy();

    if (paPrefs)
        paPrefs.destroy();

    if (paVumeter)
        paVumeter.destroy();

    if (paEqualizer)
        paEqualizer.destroy();

    if (paManager)
        paManager.destroy();
    }
}
